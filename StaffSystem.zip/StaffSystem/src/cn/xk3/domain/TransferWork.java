package cn.xk3.domain;

import java.util.Date;

public class TransferWork {
	private String old_department;
	private String new_department;
	private String old_job; 
	private String new_job;
	private Date levave_time;
	private Date work_time;
	
	public String getOld_department() {
		return old_department;
	}
	public void setOld_department(String old_department) {
		this.old_department = old_department;
	}
	public String getNew_department() {
		return new_department;
	}
	public void setNew_department(String new_department) {
		this.new_department = new_department;
	}
	public String getOld_job() {
		return old_job;
	}
	public void setOld_job(String old_job) {
		this.old_job = old_job;
	}
	public String getNew_job() {
		return new_job;
	}
	public void setNew_job(String new_job) {
		this.new_job = new_job;
	}
	public Date getLevave_time() {
		return levave_time;
	}
	public void setLevave_time(Date levave_time) {
		this.levave_time = levave_time;
	}
	public Date getWork_time() {
		return work_time;
	}
	public void setWork_time(Date work_time) {
		this.work_time = work_time;
	}
}

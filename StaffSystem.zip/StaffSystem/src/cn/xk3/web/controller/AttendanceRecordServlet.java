package cn.xk3.web.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import cn.xk3.dao.AttendanceRecordDao;
import cn.xk3.domain.BaseInfo;
import cn.xk3.domain.Page;

public class AttendanceRecordServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		
		String method = request.getParameter("method");
		if("getAll".equals(method)){
			int page = Integer.parseInt(request.getParameter("page"));
			int rows = Integer.parseInt(request.getParameter("rows"));
			long total = new AttendanceRecordDao().getTotal();
			
			List<BaseInfo> list = new AttendanceRecordDao().getStaffs(page, rows);
			Page<BaseInfo> p = new Page<BaseInfo>();
			p.setRows(list);
			p.setTotal(total);
			
			Gson gson = new GsonBuilder().create();
			response.getWriter().write(gson.toJson(p));
		}else if("query".equals(method)){
			int type = Integer.parseInt(request.getParameter("type"));
			String id = request.getParameter("id");
			response.getWriter().write(new AttendanceRecordDao().query(id,type)+"");
		}else if("queryAll".equals(method)){
			String id = request.getParameter("id");
			Gson gson = new GsonBuilder().create();
			response.getWriter().write(gson.toJson(new AttendanceRecordDao().queryAll(id)));
		}
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}

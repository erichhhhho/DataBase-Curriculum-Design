package cn.xk3.web.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.xk3.dao.TransferWorkDao;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class TransferWorkServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		
		String method = request.getParameter("method");
		if("queryTransferWork".equals(method)){
			String id = request.getParameter("id");
			Gson gson = new GsonBuilder().setDateFormat("dd/MM/yyyy").create();
			response.getWriter().write(gson.toJson(new TransferWorkDao().getTransferWorks(id)));
		}
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}

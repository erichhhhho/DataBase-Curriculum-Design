package cn.xk3.utils;

import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.Locale;

import org.apache.commons.beanutils.Converter;

public class DateTimeConverter implements Converter {

	private static final String DATE = "dd/MM/yyyy";

	public Object convert(Class type, Object value) {
		return toDate(type, value);
	}

	public static Object toDate(Class type, Object value) {
		if (value == null || "".equals(value))
			return null;
		if (value instanceof String) {
			String dateValue = value.toString().trim();
			int length = dateValue.length();
			if (type.equals(java.util.Date.class)) {
				try {
					DateFormat formatter = new SimpleDateFormat(DATE,
							new DateFormatSymbols(Locale.CHINA));
					return formatter.parse(dateValue);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return value;
	}
}

package cn.xk3.utils;

import java.io.Serializable;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.ConvertUtils;

public class FormBeanUtil {
	static {
		ConvertUtils.register(new DateTimeConverter(), java.util.Date.class);
	}

	/**
	 * ������Ϣ��װ������
	 * 
	 * @param request
	 *            ������Ϣ
	 * @param clazz
	 *            ��װ����
	 */
	@SuppressWarnings("unchecked")
	public static <E extends Serializable> E get(HttpServletRequest request,
			Class<E> clazz) {
		E obj = null;
		try {
			obj = clazz.newInstance();
			Map<String, String[]> parameterMap = request.getParameterMap();
			BeanUtils.populate(obj, parameterMap);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return obj;
	}
}

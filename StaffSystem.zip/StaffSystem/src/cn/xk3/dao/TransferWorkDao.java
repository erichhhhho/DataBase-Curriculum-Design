package cn.xk3.dao;

import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import cn.xk3.domain.TransferWork;
import cn.xk3.utils.DBUtils;

public class TransferWorkDao {
	
	public List<TransferWork> getTransferWorks(String id){
		try {
			QueryRunner runner = new QueryRunner(DBUtils.getDataSource());
			String sql = "select * from TransferWork where staff_id=?";
			return (List<TransferWork>)runner.query(sql, id, new BeanListHandler(TransferWork.class));
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}

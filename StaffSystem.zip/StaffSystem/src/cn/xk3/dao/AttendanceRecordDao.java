package cn.xk3.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import cn.xk3.domain.BaseInfo;
import cn.xk3.domain.Page;
import cn.xk3.domain.Property;
import cn.xk3.utils.DBUtils;

public class AttendanceRecordDao {
	/**
	 * ��ҳ��ȡԱ��id������
	 * 
	 * @param page
	 *            ��ʾ�ڼ�ҳԱ����Ϣ
	 * @param rows
	 *            ÿҳ��ʾ������Ա����Ϣ
	 * @return
	 */
	public List<BaseInfo> getStaffs(int page, int rows) {
		try {
			QueryRunner runner = new QueryRunner(DBUtils.getDataSource());
			String sql = "select id,name from baseinfo limit ?,?";
			Object params[] = { (page - 1) * rows, rows };
			return (List<BaseInfo>) runner.query(sql, params,
					new BeanListHandler(BaseInfo.class));
		} catch (Exception e) {
			return null;
		}
	}
	
	/**
	 * ��ȡ�ܹ�Ա����
	 * @return
	 */
	public Long getTotal(){
		try {
			QueryRunner runner = new QueryRunner(DBUtils.getDataSource());
			String sql = "select count(*) from baseinfo";
			return (Long) runner.query(sql,new ScalarHandler());
		} catch (Exception e) {
			e.printStackTrace();
			return (long) 0;
		}
	}
	
	/**
	 * 
	 * @param id 
	 * @param type 0����;  1����; 2����; 3�¼�;  4����; 5�ٵ�
	 * @return
	 */
	public Long query(String id, int type){
		try {
			QueryRunner runner = new QueryRunner(DBUtils.getDataSource());
			String sql = null;
			switch(type){
				case(0):{ sql = "SELECT COUNT(*) AS LeaveEarly_for_Work from attendancerecord WHERE staff_id=? AND leave_time< '17:00:00'";break;	}
				case(1):{ sql = "SELECT COUNT(*) AS BusinessOff from attendancerecord WHERE staff_id=? AND status=1";break;	}
				case(2):{ sql = "SELECT COUNT(*) AS Sick_leave from attendancerecord WHERE staff_id=? AND status=2";break;	}
				case(3):{ sql = "SELECT COUNT(*) AS PrivateAffair_leave from attendancerecord WHERE staff_id=? AND status=3";break;	}
				case(4):{ sql = "SELECT COUNT(*) AS Absence_from_Work from attendancerecord WHERE staff_id=? AND status=4";break;	}
				case(5):{ sql = "SELECT COUNT(*) AS Late_for_Work from attendancerecord WHERE staff_id=? AND work_time> '07:00:00'";break;	}
			}
			return (Long) runner.query(sql,id,new ScalarHandler());
		} catch (Exception e) {
			e.printStackTrace();
			return (long) 0;
		}
	}
	
	public Page<Property> queryAll(String id){
		Page<Property> page = new Page<Property>();
		List<Property> list = new ArrayList<Property>();
		
		try {
			QueryRunner runner = new QueryRunner(DBUtils.getDataSource());
			String sql = "SELECT COUNT(*) AS Late_for_Work from attendancerecord WHERE staff_id=? AND work_time> '07:00:00'";
			Property p1 = new Property("�ٵ�������", (Long)runner.query(sql,id,new ScalarHandler())+"");
			sql = "SELECT COUNT(*) AS LeaveEarly_for_Work from attendancerecord WHERE staff_id=? AND leave_time< '17:00:00'";
			Property p2 = new Property("���˴�����", (Long)runner.query(sql,id,new ScalarHandler())+"");
			sql = "SELECT COUNT(*) AS BusinessOff from attendancerecord WHERE staff_id=? AND status=1";
			Property p3 = new Property("���������", (Long)runner.query(sql,id,new ScalarHandler())+"");
			sql = "SELECT COUNT(*) AS Sick_leave from attendancerecord WHERE staff_id=? AND status=2";
			Property p4 = new Property("���ٴ�����", (Long)runner.query(sql,id,new ScalarHandler())+"");
			sql = "SELECT COUNT(*) AS PrivateAffair_leave from attendancerecord WHERE staff_id=? AND status=3";
			Property p5 = new Property("�¼ٴ�����", (Long)runner.query(sql,id,new ScalarHandler())+"");		
			sql = "SELECT COUNT(*) AS Absence_from_Work from attendancerecord WHERE staff_id=? AND status=4";
			Property p6 = new Property("����������", (Long)runner.query(sql,id,new ScalarHandler())+"");		
			list.add(p1);list.add(p2);list.add(p3);list.add(p4);list.add(p5);list.add(p6);
			page.setTotal(6);
			page.setRows(list);
			return page;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		
	}
}

package cn.xk3.dao;

import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import cn.xk3.domain.BaseInfo;
import cn.xk3.utils.DBUtils;

public class BaseInfoDao {

	/**
	 * ����Ա��������Ϣ
	 * @param bf
	 * @return
	 */
	public boolean createBaseInfo(BaseInfo bf) {
		try {
			QueryRunner runner = new QueryRunner(DBUtils.getDataSource());
			String sql = "insert into baseinfo(id,name,sex,birthplace,age," +
					"birthday,address,email,degrees,dept,hiredate) " +
					"values(?,?,?,?,?,?,?,?,?,?,?)";
			Object params[] = { bf.getId(), bf.getName(), bf.getSex(),
					bf.getBirthplace(), bf.getAge(), bf.getBirthday(),
					bf.getAddress(), bf.getEmail(), bf.getDegrees(),
					bf.getDept(), bf.getHiredate() };
			runner.update(sql, params);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	
	/**
	 * ��ҳ��ȡԱ��������Ϣ
	 * 
	 * @param pageNum
	 *            ��ʾ�ڼ�ҳԱ����Ϣ
	 * @param pageCount
	 *            ÿҳ��ʾ������Ա����Ϣ
	 * @return
	 */
	public List<BaseInfo> getBaseInfos(int page, int rows) {
		try {
			QueryRunner runner = new QueryRunner(DBUtils.getDataSource());
			String sql = "select * from baseinfo limit ?,?";
			Object params[] = { (page - 1) * rows, rows };
			return (List<BaseInfo>) runner.query(sql, params,
					new BeanListHandler(BaseInfo.class));
		} catch (Exception e) {
			return null;
		}
	}
	
	/**
	 * ��ȡ�ܹ�Ա����
	 * @return
	 */
	public Long getTotal(){
		try {
			QueryRunner runner = new QueryRunner(DBUtils.getDataSource());
			String sql = "select count(*) from baseinfo";
			return (Long) runner.query(sql,new ScalarHandler());
		} catch (Exception e) {
			e.printStackTrace();
			return (long) 0;
		}
	}
	
	/**
	 * �޸�Ա����Ϣ
	 * @param bf
	 * @return
	 */
	public boolean changeBaseInfo(BaseInfo bf){
		try {
			QueryRunner runner = new QueryRunner(DBUtils.getDataSource());
			String sql = "update baseinfo set name=?,sex=?,birthplace=?,age=?," +
					"birthday=?,address=?,email=?,degrees=?,dept=?,hiredate=? " +
					"where id=?";
			Object params[] = { bf.getName(), bf.getSex(),
					bf.getBirthplace(), bf.getAge(), bf.getBirthday(),
					bf.getAddress(), bf.getEmail(), bf.getDegrees(),
					bf.getDept(), bf.getHiredate(),bf.getId() };
			runner.update(sql, params);
			return true;
		} catch (Exception e) {
			return false;
		}
	}
	
	/**
	 * ɾ��Ա����Ϣ
	 * @param id
	 * @return
	 */
	public boolean removeBaseInfo(String id){
		try {
			QueryRunner runner = new QueryRunner(DBUtils.getDataSource());
			String sql1 = "delete from AttendanceRecord where staff_id=?";
			String sql2 = "delete from TransferWork where staff_id=?";
			String sql3 = "delete from BaseInfo where id=?";
			runner.update(sql1, id);
			runner.update(sql2, id);
			runner.update(sql3, id);
			return true;
		} catch (Exception e) {
			return false;
		}
	}
}

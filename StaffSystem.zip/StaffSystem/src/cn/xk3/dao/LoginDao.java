package cn.xk3.dao;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import cn.xk3.utils.DBUtils;

public class LoginDao {
	public boolean Login(String id,String password){
		try {
			QueryRunner runner = new QueryRunner(DBUtils.getDataSource());
			String sql="select count(*) from login where userid=? and userpwd=?";
			Object params[] = {id,password};
			return (Long)runner.query(sql,params,new ScalarHandler())==1;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
}
